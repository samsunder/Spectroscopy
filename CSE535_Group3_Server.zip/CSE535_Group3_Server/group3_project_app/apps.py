from django.apps import AppConfig


class Cse535ProjectGroup3AppConfig(AppConfig):
    name = 'group3_project_app'
