import csv
import os
import re
import numpy as np

import pandas as pd


def combinepreprocess(filename):
    df = pd.read_csv(filename, names=["X", "Y"])
    df.sort_values(by=["X"])

    x, y = df.shape
    data = []
    line = []
    protein = []
    salt = []
    oil = []

    for ln in range(x):
        xn = round(df.ix[ln, 0])
        yn = df.ix[ln, 1]
        if xn <= 850:
            protein.append(yn)
        elif xn <= 950:
            salt.append(yn)
        elif xn <= 1050:
            oil.append(yn)

    food = "".join(((filename.split(os.sep)[-1]).split(".csv")[0]).split("_")[1:])
    # print("FOOD----- ", food)
    return [np.mean(protein), np.std(protein),
            np.mean(salt), np.std(salt),
            np.mean(oil), np.std(oil),
            food]


def preprocessData(filename):
    df = pd.read_csv(filename, names=["X", "Y"])
    df.sort_values(by=["X"])

    x, y = df.shape
    data = []
    line = []
    ydata = []
    combineddata = []
    xo = 0
    max = 0
    for ln in range(x):
        xn = df.ix[ln, 0]
        xnr = round(xn)
        if xnr > xo:
            if not len(line) == 0:
                data.append(line)

            if len(line) > max:
                max = len(line)

            line = [df.ix[ln, 0], df.ix[ln, 1]]
            ydata.append(df.ix[ln, 1])
            xo = xnr
        else:
            line.append(df.ix[ln, 0])
            line.append(df.ix[ln, 1])
            ydata.append(df.ix[ln, 1])

    if not len(line) == 0:
        data.append(line)

    for d in data:
        if len(d) < max:
            x = d[0]
            y = d[-1]
            for i in range(len(d) + 1, max, 2):
                d.append(x)
                d.append(y)

    body = []
    head = []
    for i in range(max):
        head.append("X_" + str(i + 1))
        head.append("Y_" + str(i + 1))

    body.append(head)
    for d in data:
        body.append(d)

    filepart = filename.split(os.sep)

    target = os.path.join(os.sep.join(filepart[:-1]), "Processed", filepart[-1].split(".csv")[0] + "_Processed.csv")
    print("Processing ", target)

    with open(target, 'w+', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(body)
        print("Processing ", filename.split(os.sep)[-1])


def foodDiary(filename):
    df = pd.read_csv(filename)
    df = df.ix[:, 2:]
    df.reset_index(drop=True)
    row, col = df.shape
    p = re.compile("[A-Za-z ]+")
    # p = re.compile("[A-Za-z ]+")

    data = []

    for ln in range(row):
        m = p.match(df.ix[ln, 0])
        if not m == None:
            data.append([m.group(), df.ix[ln, 1]])

    dataset = set(tuple(i) for i in data)
    # data = [["Food", "Date"]]
    data = []

    for t in list(dataset):
        data.append(list(t))

    # fl = filename.split(os.sep)
    # target = os.path.join(os.sep.join(fl[:-1]))
    # target = os.path.join(target, "Processed_" + fl[-1])
    # print("TARGET:  ", target)
    filepart = filename.split(os.sep)
    target = os.path.join(os.sep.join(filepart[:-1]), "Processed", filepart[-1].split(".csv")[0] + "_Processed.csv")
    print("Processing ", target)

    with open(target, 'w+', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(data)
        print("Processing ", filename.split(os.sep)[-1])


def preprocess():
    print("BASE_DIR:  " + os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    data = []
    body = []
    head = ['Protein_F1', 'Protein_F2',
            'Salt_F1', 'Salt_F2',
            'Oil_F1', 'Oil_F2',
            'Food Item', 'Type']

    data.append(head)

    try:
        filepath = os.path.join(os.path.abspath(os.path.dirname(__file__)), "data")
        for root, dirs, files in os.walk(filepath):
            for file in files:
                if not file.endswith("_Processed.csv"):
                    if file.endswith("FoodDiary.csv"):
                        tmpfl = os.path.join(filepath, "Processed", file.split(".csv")[0] + "_Processed.csv")
                        if not os.path.isfile(tmpfl):
                            foodDiary(os.path.join(filepath, file))
                        else:
                            print("Skipping: " + file)
                            # retval += "foodDiary: " + file + "\n"
                        continue
                    if file.endswith(".csv"):
                        tmpfl = os.path.join(filepath, "Processed", file.split(".csv")[0] + "_Processed.csv")
                        # if not os.path.isfile(tmpfl):
                        #     preprocessData(os.path.join(filepath, file))
                        # else:
                        #     print("Skipping: " + file)

                        line = combinepreprocess(os.path.join(filepath, file))
                        print("Combo Processed : " + file)
                        body.append(line)
                        # data.append(line)

                        # print(body)
                        # retval += "preprocess: " + file + "\n"
    except FileNotFoundError:
        return "Failed to Process"

    matrix = np.array(body)
    matrix_name = matrix[:, -1]
    matrix_name = matrix_name.reshape(len(matrix_name), 1)
    matrix_features = matrix[:, :-1]
    matrix_features = matrix_features.astype(np.float)

    # print(matrix_features)
    min = np.amin(matrix_features)
    print(min)

    r,c = matrix_features.shape
    min_array = np.full((r, 1), abs(min) )
    # print(min_array)

    print("-------------------------------------------------")

    new_feature =np.add(matrix_features, min_array)
    # print(new_feature)

    r, c = new_feature.shape
    mean = []
    std = []
    for index in range(0, c, 2):
        feature = new_feature[:, index:index+1]
        mean.append(np.mean(feature))
        std.append(np.std(feature))

    new_matrix = np.concatenate((new_feature, matrix_name), axis=1)

    print("-------------------------------------------------")
    print(mean, std)

    print(matrix.shape, matrix_features.shape, matrix_name.shape)


    for entry in new_matrix:
        entry_mean  = []
        entry_std = []
        for c in range(len(mean)):
            index = 2*c
            e_feat = np.array(entry[index:index+2])
            e_feat = e_feat.astype(np.float)
            entry_mean.append(np.mean(e_feat))
            entry_std.append(np.std(e_feat))

        score = ""

        for index in range(len(mean)):
            if entry_mean[index] > mean[index]:
                score += "1"
            else:
                score += "0"

        type = 0
        # if score in ['000','010','100','110']:
        #     type = 2
        # elif score in ['001','101', '111']:
        #     type = 1
        # else:
        #     type = 0
        if score in ['001','101', '111']:
            type = 0
        else:
            type = 1
        print("{}: {} --- {} | {}".format(entry[-1], score, type, entry.shape))

        entry = np.append(entry, type)
        data.append(entry)
        data.append(entry)
        data.append(entry)

    # print(min_array)
    # data.append(head)
    # data.append(body)
    # print("Complete Data\n{}".format(data))
    target = os.path.join(os.path.abspath(os.path.dirname(__file__)), "data", "Processed", "Combined_Scan_Processed.csv")
    with open(target, 'w+', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(data)
        print("Processed ", target.split(os.sep)[-1])


    return "Success"
