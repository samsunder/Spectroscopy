import os
import pickle

import pandas as pd
from scipy.fftpack import fft
from sklearn import decomposition
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC


def partition(filename):
    global train_success_output
    global train_features
    global test_success_output
    global test_features
    global complete_features

    df = pd.read_csv(filename)
    df = df.sample(frac=1).reset_index(drop=True)

    ratio = 0.8
    traindata, testdata = train_test_split(df, test_size=(1 - ratio))

    train_success_output = traindata.ix[:, -1].values.tolist()
    train_features = traindata.ix[:, :-2]
    test_success_output = testdata.ix[:, -1].values.tolist()
    test_features = testdata.ix[:, :-2]

    complete_features = df.ix[:, :-2]


def extractPCA():
    global train_success_output
    global train_features
    global test_success_output
    global test_features
    global complete_features
    # complete_features = partition(filename)

    pca = decomposition.PCA()
    pca.fit(complete_features)

    train_features = pca.transform(train_features)
    test_features = pca.transform(test_features)


def extractFFT():
    global train_success_output
    global train_features
    global test_success_output
    global test_features
    global complete_features

    print(test_features)

    train_features = fft(train_features)
    test_features = fft(test_features)

    print(test_features)


def extractLDA():
    global train_success_output
    global train_features
    global test_success_output
    global test_features
    global complete_features

    print(test_features)

    lda = decomposition.LatentDirichletAllocation()
    lda.fit(complete_features)
    train_features = lda.transform(train_features)
    test_features = lda.transform(test_features)

    print(test_features)


def extractNMF():
    global train_success_output
    global train_features
    global test_success_output
    global test_features
    global complete_features

    print(test_features)

    nmf = decomposition.NMF()
    nmf.fit(complete_features)
    train_features = nmf.transform(train_features)
    test_features = nmf.transform(test_features)

    print(test_features)


def extractFastICA():
    global train_success_output
    global train_features
    global test_success_output
    global test_features
    global complete_features

    print(test_features)

    ica = decomposition.FastICA()
    ica.fit(complete_features)
    train_features = ica.transform(train_features)
    test_features = ica.transform(test_features)

    print(test_features)


def trainNaiveBayes(modelfile):
    result = ""
    clf = GaussianNB()
    clf.fit(train_features, train_success_output)

    trainpredicted = clf.predict(train_features)
    testpredicted = clf.predict(test_features)

    correct = 0
    for i in range(len(trainpredicted)):

        if trainpredicted[i] == train_success_output[i]:
            correct += 1

    acc = (correct * 100) / len(trainpredicted)
    acc = (round(acc * 100.0)) / 100.0
    print("NB: Train Accuracy: {}%".format(acc), sep="\t\t")
    result += str(acc)
    result += "::"

    correct = 0
    for i in range(len(testpredicted)):

        if testpredicted[i] == test_success_output[i]:
            correct += 1

    acc = (correct * 100) / len(testpredicted)
    acc = (round(acc * 100.0)) / 100.0
    print("NB: Test Accuracy: {}%".format(acc), sep="\t\t")
    result += str(acc)

    pickle.dump(clf, open(modelfile, 'wb'))

    return result


def trainLogisticRegression(modelfile):
    result = ""
    clf = LogisticRegression()
    clf.fit(train_features, train_success_output)

    trainpredicted = clf.predict(train_features)
    testpredicted = clf.predict(test_features)

    correct = 0
    for i in range(len(trainpredicted)):

        if trainpredicted[i] == train_success_output[i]:
            correct += 1

    acc = (correct * 100) / len(trainpredicted)
    acc = (round(acc * 100.0)) / 100.0
    print("NB: Train Accuracy: {}%".format(acc), sep="\t\t")
    result += str(acc)
    result += "::"

    correct = 0
    for i in range(len(testpredicted)):

        if testpredicted[i] == test_success_output[i]:
            correct += 1

    acc = (correct * 100) / len(testpredicted)
    acc = (round(acc * 100.0)) / 100.0
    print("NB: Test Accuracy: {}%".format(acc), sep="\t\t")
    result += str(acc)

    pickle.dump(clf, open(modelfile, 'wb'))

    return result


def trainSVM(modelfile):
    result = ""
    clf = SVC()
    clf.fit(train_features, train_success_output)

    trainpredicted = clf.predict(train_features)
    testpredicted = clf.predict(test_features)

    correct = 0
    for i in range(len(trainpredicted)):

        if trainpredicted[i] == train_success_output[i]:
            correct += 1

    acc = (correct * 100) / len(trainpredicted)
    acc = (round(acc * 100.0)) / 100.0
    print("NB: Train Accuracy: {}%".format(acc), sep="\t\t")
    result += str(acc)
    result += "::"

    correct = 0
    for i in range(len(testpredicted)):

        if testpredicted[i] == test_success_output[i]:
            correct += 1

    acc = (correct * 100) / len(testpredicted)
    acc = (round(acc * 100.0)) / 100.0
    print("NB: Test Accuracy: {}%".format(acc), sep="\t\t")
    result += str(acc)

    pickle.dump(clf, open(modelfile, 'wb'))

    return result


def trainKNN(modelfile):
    result = ""
    clf = KNeighborsClassifier(n_neighbors=5)
    clf.fit(train_features, train_success_output)

    trainpredicted = clf.predict(train_features)
    testpredicted = clf.predict(test_features)

    correct = 0
    for i in range(len(trainpredicted)):

        if trainpredicted[i] == train_success_output[i]:
            correct += 1

    acc = (correct * 100) / len(trainpredicted)
    acc = (round(acc * 100.0)) / 100.0
    print("KNN: Train Accuracy: {}%".format(acc), sep="\t\t")
    result += str(acc)
    result += "::"

    correct = 0
    for i in range(len(testpredicted)):

        if testpredicted[i] == test_success_output[i]:
            correct += 1

    acc = (correct * 100) / len(testpredicted)
    acc = (round(acc * 100.0)) / 100.0
    print("KNN: Test Accuracy: {}%".format(acc), sep="\t\t")
    result += str(acc)

    pickle.dump(clf, open(modelfile, 'wb'))

    return result


def trainRandomForest(modelfile):
    result = ""
    clf = RandomForestClassifier(n_jobs=2, random_state=0)
    clf.fit(train_features, train_success_output)

    trainpredicted = clf.predict(train_features)
    testpredicted = clf.predict(test_features)

    correct = 0
    for i in range(len(trainpredicted)):

        if trainpredicted[i] == train_success_output[i]:
            correct += 1

    acc = (correct * 100) / len(trainpredicted)
    acc = (round(acc * 100.0)) / 100.0
    print("RF: Max Depth: None, Train Accuracy: {}%".format(acc), sep="\t\t")
    result += str(acc)
    result += "::"


    correct = 0
    for i in range(len(testpredicted)):

        if testpredicted[i] == test_success_output[i]:
            correct += 1

    acc = (correct * 100) / len(testpredicted)
    acc = (round(acc * 100.0)) / 100.0
    print("RF: Max Depth: None, Test Accuracy: {}%".format(acc), sep="\t\t")
    result += str(acc)

    pickle.dump(clf, open(modelfile, 'wb'))

    return result


def test(modelfile):
    clf = pickle.load(open(modelfile, 'rb'))
    feature = [[0.1, 0.2, 0]]
    p = clf.predict_proba(feature)
    print("[TEST] -- ", p)


def dotrain(fe=0, ml=0):
    datafile = os.path.join(os.path.abspath(os.path.dirname(__file__)), "data", "Processed",
                            "Combined_Scan_Processed.csv")

    acc = -1
    modelname = ""

    print("FE:{}  ML:{}".format(fe, ml))

    partition(datafile)

    if fe in [1, '1']:
        modelname = "pca_"
        extractPCA()
    elif fe in [2, '2']:
        modelname = "fft_"
        extractFFT()
    elif fe in [3, '3']:
        modelname = "ica_"
        extractFastICA()
    elif fe in [4, '4']:
        modelname = "lda_"
        extractLDA()
    elif fe in [5, '5']:
        modelname = "nmf_"
        extractNMF()
    elif fe in [0, '0']:
        modelname = "complete_"

    if ml in [1, '1']:
        modelname += "naivebayes.m"
        modelfile = os.path.join(os.path.abspath(os.path.dirname(__file__)), "ml_models", modelname)
        acc = trainNaiveBayes(modelfile)
        print("YO NB!!", acc)
        # TODO
        pass
    elif ml in [2, '2']:
        modelname += "logisticregr.m"
        modelfile = os.path.join(os.path.abspath(os.path.dirname(__file__)), "ml_models", modelname)
        acc = trainLogisticRegression(modelfile)
        print("YO LR!!", acc)
    elif ml in [3, '3']:
        modelname += "svm.m"
        modelfile = os.path.join(os.path.abspath(os.path.dirname(__file__)), "ml_models", modelname)
        acc = trainSVM(modelfile)
        print("YO SVM!!", acc)
    elif ml in [4, '4']:
        modelname += "knn.m"
        modelfile = os.path.join(os.path.abspath(os.path.dirname(__file__)), "ml_models", modelname)
        acc = trainKNN(modelfile)
        print("YO KNN!!", acc)
    elif ml in [5, '5']:
        modelname += "randomforest.m"
        modelfile = os.path.join(os.path.abspath(os.path.dirname(__file__)), "ml_models", modelname)
        acc = trainRandomForest(modelfile)
        print("YO RF!!", acc)

    # modelfile = os.path.join(os.path.abspath(os.path.dirname(__file__)), "ml_models", "pca_random_forest.m")
    # PCA(datafile)
    # acc = trainRandomForest(modelfile)
    # print("Hello World ", acc)
    # test(modelfile)
    return acc


complete_features = train_success_output = train_features = test_success_output = test_features = None
if __name__ == '__main__':
    dotrain()
