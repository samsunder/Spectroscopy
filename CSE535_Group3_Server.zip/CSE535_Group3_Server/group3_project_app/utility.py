import os
from wsgiref.util import FileWrapper

from django.http import HttpResponse

from . import preprocess as prep
from . import machine_learning as ml


def test():
    return "Dummy Home Page for CSE535 Project (Group3)"


def preprocess():
    return prep.preprocess()


def downloadfood():
    filepath = os.path.join(os.path.abspath(os.path.dirname(__file__)), "data", "Processed", "FoodDiary_Processed.csv")
    csvFile = open(filepath, 'r')
    myfile = FileWrapper(csvFile)
    response = HttpResponse(myfile, content_type='application/csv')
    response['Content-Disposition'] = 'attachment; filename=test.csv'
    return response


def downloaddata():
    filepath = os.path.join(os.path.abspath(os.path.dirname(__file__)), "data", "Processed",
                            "Combined_Scan_Processed.csv")
    csvFile = open(filepath, 'r')
    myfile = FileWrapper(csvFile)
    response = HttpResponse(myfile, content_type='application/csv')
    response['Content-Disposition'] = 'attachment; filename=test.csv'
    return response


def traindata(_fe, _ml):
    response = ml.dotrain(_fe, _ml)
    return response