import os

from django.http import HttpResponse
from django.shortcuts import render

from . import utility as util
from .forms import UploadFileForm


# Create your views here.

def index(request):
    return HttpResponse("<h2>" + util.test() + "</h2>")


def dataprep(request):
    return HttpResponse("<h2>" + util.preprocess() + "</h2>")


def downloadfood(request):
    return util.downloadfood()


def downloaddata(request):
    return util.downloaddata()


def train(request):
    print("REQ: ", request)
    FE = request.GET.get('FE', '0')
    ML = request.GET.get('ML', '0')
    print("FE: ", FE)
    print("ML: ", ML)
    return HttpResponse(util.traindata(FE, ML))


def home(request):
    return render(request, 'upload.html', {'what': 'Django File Upload'})


def uploadfile(request):
    print("------>" + request.method)
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        print("------>" + form.title, form.file)
        if form.is_valid():
            handle_uploaded_file(request.FILES['file'])
            return HttpResponse('success')
    else:
        form = UploadFileForm()
    return render(request, 'upload.html', {'form': form})


def handle_uploaded_file(file, filename):
    filepath = filepath = os.path.join(os.path.abspath(os.path.dirname(__file__)), "data")
    if not os.path.exists(filepath):
        os.mkdir('filepath')

    with open(os.path.join(filepath, filename), 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)
